DROP TABLE IF EXISTS `ac_banners`;
DROP TABLE IF EXISTS `ac_banner_descriptions`;
DROP TABLE IF EXISTS `ac_banner_stat`;
DELETE FROM `ac_resource_map` WHERE `object_name`='banners';