DROP INDEX `ac_realex_orders_idx` ON `ac_realex_orders`;
DROP TABLE IF EXISTS `ac_realex_orders`;

DROP TABLE IF EXISTS `ac_realex_order_transactions`;
